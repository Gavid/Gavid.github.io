#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QNetworkAccessManager>    //加载网络请求头文件
#include <QNetworkReply>
#include <QNetworkRequest>      //加载发送请求头文件



namespace Ui {
class Widget;
}

class Widget : public QWidget
{
    Q_OBJECT

public:
    explicit Widget(QWidget *parent = 0);
    ~Widget();

private slots:
    void on_btn_sure_clicked();
    void oneProcessFinished(QNetworkReply*);

private:
    Ui::Widget *ui;
    QNetworkAccessManager *manage;      //定义

    void Init();        //初始化函数
};

#endif // WIDGET_H
