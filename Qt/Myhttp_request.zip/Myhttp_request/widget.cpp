#include "widget.h"
#include "ui_widget.h"

Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);
    Init();
}

Widget::~Widget()
{
    delete ui;
}

void Widget::Init()
{
    manage = new QNetworkAccessManager(this);       //分配空间
    connect(manage,SIGNAL(finished(QNetworkReply*)),this,SLOT(oneProcessFinished(QNetworkReply*)));     //绑定完成信号
}

//绑定完成信号函数
void Widget::oneProcessFinished(QNetworkReply *reply)
{
    QString str = reply->readAll();
    ui->textEdit->setText(str);
}

void Widget::on_btn_sure_clicked()
{
    QString url = ui->lineEdit_url->text();     //获取地址
    manage->get(QNetworkRequest(QUrl(url)));    //请求实现
}
